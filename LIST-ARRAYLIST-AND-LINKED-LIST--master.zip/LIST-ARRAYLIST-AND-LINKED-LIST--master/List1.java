package day1example;
interface  List1 {
 public void Add(int value );
 public void Add(int value,int index);
 public void remove(int index);
 public void search(int value);
 public void traverse();
 public boolean exit();
}
