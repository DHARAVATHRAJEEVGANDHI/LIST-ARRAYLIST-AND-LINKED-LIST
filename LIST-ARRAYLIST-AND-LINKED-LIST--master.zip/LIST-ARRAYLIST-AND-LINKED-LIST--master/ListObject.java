package finalimplents;

public class ListObject<DataType> {
	DataType value;
	ListObject next,tail,head,temp;
	ListObject(DataType  d){
		value= d;
		next=null;	
	}

}
