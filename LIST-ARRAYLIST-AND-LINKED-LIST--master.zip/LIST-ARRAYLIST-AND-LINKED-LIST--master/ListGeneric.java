package finalimplents;

  interface ListGeneric<D> {
	public void Add(D i);
	public void Add(int index);
	public void remove(int index);
	public void traverse();
	

}
